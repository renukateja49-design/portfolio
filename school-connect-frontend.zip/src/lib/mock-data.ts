export const student = {
  name: "Aarav Sharma",
  id: "2511CS020451",
  class: "Class X",
  section: "OMEGA",
  roll: "2511CS020451",
  photo: "https://api.dicebear.com/9.x/avataaars/svg?seed=Aarav&backgroundColor=b6e3f4",
  dob: "Jan 24, 2008",
  gender: "MALE",
  mobile: "9110520228",
  email: "2511cs020451@mallareddyuniversity.ac.in",
  father: "SIRIGE SATISH KUMAR",
  mother: "SIRIGE MADHULATHA",
  parentMobile: "9110520228",
  bloodGroup: "N/A",
  admissionNo: "ADM-2021-0451",
  academicYear: "2025 - 2026",
  batch: "2025 - 2026",
  degree: "B.TECH",
  programCode: "AI&ML",
  semester: "2",
  house: "Sapphire",
  attendance: 90.89,
  fees: { total: 85000, paid: 85000, due: 0 },
  cgpa: "9.2",
};

export const courses = [
  { code: "MAT", name: "Mathematics", faculty: "Mrs. R. Iyer", tint: "violet" },
  { code: "PHY", name: "Physics", faculty: "Mr. S. Reddy", tint: "peach" },
  { code: "CHE", name: "Chemistry", faculty: "Ms. K. Menon", tint: "mint" },
  { code: "BIO", name: "Biology", faculty: "Dr. A. Banerjee", tint: "rose" },
  { code: "ENG", name: "English Literature", faculty: "Mrs. P. Kapoor", tint: "sky" },
  { code: "CSC", name: "Computer Science", faculty: "Mr. V. Naidu", tint: "violet" },
  { code: "SST", name: "Social Studies", faculty: "Mr. D. Khanna", tint: "peach" },
] as const;

export const notices = [
  {
    id: 1,
    author: "SCHOOL CONNECT | PRINCIPAL",
    time: "Jun 6, 2026 12:51 PM",
    title: "Annual Science Exhibition 2026",
    body: "Our annual science exhibition is back! Students from classes VIII–XII will showcase innovative projects across robotics, AI, sustainability and biotech. Parents are warmly invited.",
    tag: "Announcements",
  },
  {
    id: 2,
    author: "ACADEMICS OFFICE",
    time: "Jun 5, 2026 09:10 AM",
    title: "Half-Yearly Exam Timetable Released",
    body: "The half-yearly exam timetable has been published. Please check the Exams section for subject-wise dates and hall ticket downloads.",
    tag: "Posts",
  },
  {
    id: 3,
    author: "SPORTS DEPARTMENT",
    time: "Jun 3, 2026 04:20 PM",
    title: "Inter-house Athletics Meet",
    body: "Trials for the inter-house athletics meet begin next Monday. Sign up with your house captain before Friday.",
    tag: "Urgent",
  },
];

export const homework = [
  { id: 1, subject: "Mathematics", title: "Exercise 4.3 – Quadratic Equations", due: "Tomorrow", status: "Pending" },
  { id: 2, subject: "Physics", title: "Lab report: Refraction", due: "Jun 10", status: "Submitted" },
  { id: 3, subject: "English", title: "Essay – The Road Not Taken", due: "Jun 12", status: "Pending" },
  { id: 4, subject: "Chemistry", title: "Worksheet 2 – Periodic Table", due: "Jun 9", status: "Reviewed" },
];

export const notifications = [
  { id: 1, kind: "attendance", title: "Marked Present today", time: "9:05 AM", body: "Period 1 attendance recorded." },
  { id: 2, kind: "homework", title: "New Homework in Mathematics", time: "Yesterday", body: "Exercise 4.3 added by Mrs. Iyer." },
  { id: 3, kind: "fee", title: "Term 2 Fee Receipt available", time: "Jun 1", body: "Receipt #INV-20451 ready to download." },
  { id: 4, kind: "exam", title: "Half-Yearly Timetable", time: "May 30", body: "Check the exams section for details." },
];

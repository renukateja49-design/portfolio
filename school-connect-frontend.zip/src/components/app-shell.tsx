import { Link, useRouterState } from "@tanstack/react-router";
import { AnimatePresence, motion } from "framer-motion";
import { Home, BookOpen, Bell, LifeBuoy, User, Menu, X, Calendar, Wallet, GraduationCap, Video, Trophy, ClipboardList, Sparkles, LogOut, Settings, BookMarked } from "lucide-react";
import { useState, type ReactNode } from "react";
import { student } from "@/lib/mock-data";

const tabs = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/academics", icon: BookOpen, label: "Academics" },
  { to: "/notifications", icon: Bell, label: "Updates" },
  { to: "/support", icon: LifeBuoy, label: "Support" },
  { to: "/profile", icon: User, label: "Profile" },
] as const;

const drawerItems = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/profile", icon: User, label: "Profile" },
  { to: "/attendance", icon: Calendar, label: "Attendance" },
  { to: "/homework", icon: ClipboardList, label: "Homework" },
  { to: "/academics", icon: BookOpen, label: "Learning Management" },
  { to: "/online-classes", icon: Video, label: "Online Classes" },
  { to: "/results", icon: GraduationCap, label: "Results" },
  { to: "/exams", icon: BookMarked, label: "Exams" },
  { to: "/fees", icon: Wallet, label: "Fees" },
  { to: "/showcase", icon: Sparkles, label: "Our School" },
  { to: "/notifications", icon: Bell, label: "Notifications" },
  { to: "/support", icon: LifeBuoy, label: "Helpdesk" },
] as const;

export function AppShell({
  title,
  children,
  centerTitle = false,
  showHeader = true,
  rightSlot,
}: {
  title?: ReactNode;
  children: ReactNode;
  centerTitle?: boolean;
  showHeader?: boolean;
  rightSlot?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="relative mx-auto min-h-screen w-full max-w-[480px] bg-surface text-foreground">
      {/* Sidebar drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-40 bg-black/40"
            />
            <motion.aside
              key="drawer"
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="fixed inset-y-0 left-0 z-50 flex w-[78%] max-w-[360px] flex-col bg-brand text-brand-foreground"
            >
              <div className="flex items-center justify-between px-6 pt-6">
                <h2 className="text-2xl font-bold">Menu</h2>
                <button
                  onClick={() => setOpen(false)}
                  className="rounded-full p-2 hover:bg-white/10"
                  aria-label="Close menu"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="px-6 pt-6">
                <div className="h-20 w-20 overflow-hidden rounded-2xl bg-white/10 ring-1 ring-white/20">
                  <img src={student.photo} alt={student.name} className="h-full w-full object-cover" />
                </div>
                <div className="mt-4">
                  <div className="text-xl font-bold leading-tight uppercase tracking-wide">{student.name}</div>
                  <div className="mt-1 text-sm text-white/60">ID : {student.id}</div>
                </div>
              </div>

              <nav className="mt-6 flex-1 overflow-y-auto px-2 pb-6">
                {drawerItems.map((item) => {
                  const active = pathname === item.to;
                  return (
                    <Link
                      key={item.to}
                      to={item.to}
                      onClick={() => setOpen(false)}
                      className={`group flex items-center gap-3 rounded-xl px-4 py-3 text-[15px] font-medium transition-colors ${
                        active ? "bg-white/10 text-white" : "text-white/80 hover:bg-white/5 hover:text-white"
                      }`}
                    >
                      <item.icon className="h-[18px] w-[18px] opacity-80" />
                      {item.label}
                    </Link>
                  );
                })}
                <div className="my-3 mx-4 border-t border-white/10" />
                <button className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-[15px] font-medium text-white/70 hover:bg-white/5 hover:text-white">
                  <Settings className="h-[18px] w-[18px]" /> Settings
                </button>
                <button className="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-[15px] font-medium text-white/60 hover:bg-white/5 hover:text-white">
                  <LogOut className="h-[18px] w-[18px]" /> Logout
                </button>
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      {/* Header */}
      {showHeader && (
        <header className="sticky top-0 z-30 flex items-center gap-3 bg-surface/80 px-4 pb-3 pt-5 backdrop-blur-md">
          <button
            onClick={() => setOpen(true)}
            className="-ml-1 rounded-lg p-2 hover:bg-secondary"
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>
          <div className={`flex-1 ${centerTitle ? "text-center" : ""}`}>
            {typeof title === "string" ? (
              <h1 className="text-[22px] font-bold tracking-tight">{title}</h1>
            ) : (
              title
            )}
          </div>
          {rightSlot ?? (
            <button className="relative rounded-xl p-2 hover:bg-secondary" aria-label="Notifications">
              <Bell className="h-5 w-5" />
              <span className="absolute right-2 top-2 h-1.5 w-1.5 rounded-full bg-destructive" />
            </button>
          )}
        </header>
      )}

      {/* Animated content with main slide on drawer */}
      <motion.main
        animate={{ scale: open ? 0.96 : 1, x: open ? 24 : 0, borderRadius: open ? 24 : 0 }}
        transition={{ type: "spring", stiffness: 280, damping: 30 }}
        className="relative z-10 min-h-[calc(100vh-64px)] origin-left overflow-hidden bg-surface pb-28"
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.22, ease: "easeOut" }}
          >
            {children}
          </motion.div>
        </AnimatePresence>
      </motion.main>

      {/* Bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-[480px] items-center justify-around border-t border-border bg-card/95 px-2 py-2 backdrop-blur-md">
        {tabs.map((tab) => {
          const active = tab.to === "/" ? pathname === "/" : pathname.startsWith(tab.to);
          return (
            <Link key={tab.to} to={tab.to} className="relative flex flex-1 flex-col items-center py-1.5">
              <motion.div
                whileTap={{ scale: 0.9 }}
                className={`flex h-10 w-10 items-center justify-center rounded-2xl transition-colors ${
                  active ? "bg-accent text-brand" : "text-muted-foreground"
                }`}
              >
                <tab.icon className="h-5 w-5" strokeWidth={active ? 2.4 : 1.8} />
              </motion.div>
              {active && (
                <motion.span
                  layoutId="bn-dot"
                  className="mt-0.5 h-1 w-1 rounded-full bg-brand"
                  transition={{ type: "spring", stiffness: 400, damping: 28 }}
                />
              )}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Trophy } from "lucide-react";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/showcase")({
  head: () => ({ meta: [{ title: "Our School – School Connect" }] }),
  component: Showcase,
});

const achievements = [
  { title: "National Robotics Champions 2025", desc: "Team Sapphire won gold at NRC Bangalore.", tint: "violet" },
  { title: "CBSE Topper – Aanya Verma", desc: "Scored 99.4% in class XII boards.", tint: "peach" },
  { title: "Inter-school Olympiad", desc: "12 medals across maths & science.", tint: "mint" },
];

const gallery = ["Campus", "Sports", "Events", "Labs", "Library", "Celebrations"];

function Showcase() {
  return (
    <AppShell title="Our School">
      <div className="px-4 pt-2">
        <div className="rounded-2xl bg-gradient-brand p-5 text-brand-foreground shadow-card">
          <div className="text-xs uppercase tracking-wider text-white/70">Est. 1998 · CBSE Affiliated</div>
          <div className="mt-1 text-2xl font-extrabold leading-tight">Where curiosity becomes excellence.</div>
          <p className="mt-3 text-sm text-white/85">A future-ready campus nurturing 4,800+ students across pre-primary to grade XII, with world-class faculty and modern labs.</p>
        </div>

        <h2 className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Achievements</h2>
        <div className="mt-3 space-y-3">
          {achievements.map((a, i) => (
            <motion.div
              key={a.title}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="flex items-start gap-3 rounded-2xl bg-card p-4 shadow-card"
            >
              <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-tint-${a.tint} text-tint-${a.tint}-foreground`}>
                <Trophy className="h-5 w-5" />
              </div>
              <div>
                <div className="text-[15px] font-bold">{a.title}</div>
                <div className="text-xs text-muted-foreground">{a.desc}</div>
              </div>
            </motion.div>
          ))}
        </div>

        <h2 className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Gallery</h2>
        <div className="mt-3 grid grid-cols-2 gap-3">
          {gallery.map((g, i) => (
            <div
              key={g}
              className="relative h-28 overflow-hidden rounded-2xl bg-gradient-brand shadow-card"
              style={{ filter: `hue-rotate(${i * 30}deg)` }}
            >
              <div className="absolute inset-x-3 bottom-2 text-sm font-bold text-white">{g}</div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

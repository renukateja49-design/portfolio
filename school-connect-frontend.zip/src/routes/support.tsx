import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Phone, Mail, MessageCircle, FileText, BookOpen, Wallet, Bus, Wrench } from "lucide-react";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/support")({
  head: () => ({ meta: [{ title: "Helpdesk – School Connect" }] }),
  component: Support,
});

const contacts = [
  { icon: Phone, label: "Call School", value: "+91 80000 12345", tint: "mint" },
  { icon: Mail, label: "Email", value: "help@schoolconnect.edu.in", tint: "sky" },
  { icon: MessageCircle, label: "WhatsApp", value: "+91 80000 12345", tint: "violet" },
  { icon: FileText, label: "Raise a Ticket", value: "Track in 24 hrs", tint: "peach" },
] as const;

const categories = [
  { icon: BookOpen, label: "Academic" },
  { icon: Wallet, label: "Fees" },
  { icon: Wrench, label: "Technical" },
  { icon: Bus, label: "Transport" },
] as const;

function Support() {
  return (
    <AppShell title="Helpdesk">
      <div className="px-4 pt-2">
        <div className="grid grid-cols-2 gap-3">
          {contacts.map((c, i) => (
            <motion.button
              key={c.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              whileTap={{ scale: 0.97 }}
              className="flex flex-col items-start gap-3 rounded-2xl bg-card p-4 text-left shadow-card"
            >
              <div className={`grid h-11 w-11 place-items-center rounded-xl bg-tint-${c.tint} text-tint-${c.tint}-foreground`}>
                <c.icon className="h-5 w-5" />
              </div>
              <div>
                <div className="text-[15px] font-bold">{c.label}</div>
                <div className="text-xs text-muted-foreground">{c.value}</div>
              </div>
            </motion.button>
          ))}
        </div>

        <h2 className="mt-7 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Quick Categories</h2>
        <div className="mt-3 space-y-2">
          {categories.map((c) => (
            <button key={c.label} className="flex w-full items-center gap-3 rounded-2xl bg-card p-4 text-left shadow-card hover:bg-secondary/40">
              <c.icon className="h-5 w-5 text-brand" />
              <span className="font-semibold">{c.label} Queries</span>
            </button>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

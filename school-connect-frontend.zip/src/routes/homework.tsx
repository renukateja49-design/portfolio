import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppShell } from "@/components/app-shell";
import { homework } from "@/lib/mock-data";

export const Route = createFileRoute("/homework")({
  head: () => ({ meta: [{ title: "Homework – School Connect" }] }),
  component: HW,
});

const tints: Record<string, string> = { Pending: "peach", Submitted: "mint", Reviewed: "violet" };

function HW() {
  return (
    <AppShell title="Homework">
      <div className="space-y-3 px-4 pt-2">
        {homework.map((h, i) => (
          <motion.div
            key={h.id}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="rounded-2xl bg-card p-4 shadow-card"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">{h.subject}</div>
                <div className="mt-1 text-[15px] font-bold leading-tight">{h.title}</div>
                <div className="mt-1 text-xs text-muted-foreground">Due {h.due}</div>
              </div>
              <span className={`shrink-0 rounded-full bg-tint-${tints[h.status]} px-3 py-1 text-[11px] font-bold text-tint-${tints[h.status]}-foreground`}>
                {h.status}
              </span>
            </div>
          </motion.div>
        ))}
      </div>
    </AppShell>
  );
}

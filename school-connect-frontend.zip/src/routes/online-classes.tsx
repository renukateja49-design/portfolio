import { createFileRoute } from "@tanstack/react-router";
import { Video } from "lucide-react";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/online-classes")({
  head: () => ({ meta: [{ title: "Online Classes – School Connect" }] }),
  component: OC,
});

const classes = [
  { subject: "Mathematics", faculty: "Mrs. R. Iyer", time: "10:00 AM", platform: "Google Meet", live: true },
  { subject: "Physics", faculty: "Mr. S. Reddy", time: "11:30 AM", platform: "Zoom", live: false },
  { subject: "Chemistry", faculty: "Ms. K. Menon", time: "01:30 PM", platform: "MS Teams", live: false },
];

function OC() {
  return (
    <AppShell title="Online Classes">
      <div className="space-y-3 px-4 pt-2">
        {classes.map((c) => (
          <div key={c.subject} className="rounded-2xl bg-card p-4 shadow-card">
            <div className="flex items-start justify-between">
              <div>
                <div className="text-[15px] font-bold">{c.subject}</div>
                <div className="text-xs text-muted-foreground">{c.faculty} · {c.platform}</div>
                <div className="mt-1 text-sm font-semibold text-brand">{c.time}</div>
              </div>
              <button
                className={`flex items-center gap-1.5 rounded-full px-4 py-2 text-xs font-bold ${
                  c.live ? "bg-gradient-brand text-brand-foreground" : "bg-secondary text-muted-foreground"
                }`}
              >
                <Video className="h-3.5 w-3.5" /> {c.live ? "Join" : "Upcoming"}
              </button>
            </div>
          </div>
        ))}
      </div>
    </AppShell>
  );
}

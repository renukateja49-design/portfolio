import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/results")({
  head: () => ({ meta: [{ title: "Results – School Connect" }] }),
  component: Results,
});

const subjects = [
  { name: "Mathematics", marks: 96, grade: "A+" },
  { name: "Physics", marks: 91, grade: "A+" },
  { name: "Chemistry", marks: 88, grade: "A" },
  { name: "Biology", marks: 84, grade: "A" },
  { name: "English", marks: 92, grade: "A+" },
  { name: "Computer Sc.", marks: 98, grade: "A+" },
];

function Results() {
  const avg = Math.round(subjects.reduce((a, s) => a + s.marks, 0) / subjects.length);
  return (
    <AppShell title="Results">
      <div className="px-4 pt-2">
        <div className="grid grid-cols-3 gap-3">
          <div className="rounded-2xl bg-tint-violet p-4 text-center shadow-card">
            <div className="text-2xl font-extrabold text-tint-violet-foreground">{avg}%</div>
            <div className="text-xs font-semibold text-foreground/70">Average</div>
          </div>
          <div className="rounded-2xl bg-tint-mint p-4 text-center shadow-card">
            <div className="text-2xl font-extrabold text-tint-mint-foreground">A+</div>
            <div className="text-xs font-semibold text-foreground/70">Grade</div>
          </div>
          <div className="rounded-2xl bg-tint-peach p-4 text-center shadow-card">
            <div className="text-2xl font-extrabold text-tint-peach-foreground">#3</div>
            <div className="text-xs font-semibold text-foreground/70">Rank</div>
          </div>
        </div>

        <div className="mt-5 rounded-2xl bg-card p-4 shadow-card">
          <div className="mb-2 text-sm font-bold">Subject-wise marks</div>
          <div className="space-y-3">
            {subjects.map((s, i) => (
              <div key={s.name}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="font-medium">{s.name}</span>
                  <span className="text-muted-foreground">{s.marks} · {s.grade}</span>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${s.marks}%` }}
                    transition={{ duration: 0.8, delay: i * 0.05 }}
                    className="h-full rounded-full bg-gradient-brand"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

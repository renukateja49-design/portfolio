import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { notices } from "@/lib/mock-data";
import { GraduationCap } from "lucide-react";

export const Route = createFileRoute("/notifications")({
  head: () => ({ meta: [{ title: "Digital Notice Board – School Connect" }] }),
  component: Notif,
});

const filters = ["All", "Posts", "Announcements", "Polls", "Urgent"] as const;

function Notif() {
  const [filter, setFilter] = useState<(typeof filters)[number]>("All");
  const items = filter === "All" ? notices : notices.filter((n) => n.tag === filter);

  return (
    <AppShell title="Digital Notice Board">
      <div className="px-4 pt-1">
        <div className="-mx-4 flex gap-2 overflow-x-auto px-4 pb-3">
          {filters.map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`shrink-0 rounded-full border px-4 py-1.5 text-sm font-semibold transition ${
                filter === f
                  ? "border-brand text-brand"
                  : "border-transparent bg-secondary text-muted-foreground"
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {items.map((n, i) => (
            <motion.article
              key={n.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="rounded-2xl bg-card p-4 shadow-card"
            >
              <header className="flex items-start gap-3">
                <div className="grid h-10 w-10 place-items-center rounded-full bg-tint-violet text-tint-violet-foreground">
                  <GraduationCap className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-[13px] font-bold tracking-wide text-foreground">{n.author}</div>
                  <div className="text-xs text-muted-foreground">{n.time}</div>
                </div>
              </header>
              <div className="mt-4 rounded-xl bg-gradient-brand p-4 text-brand-foreground">
                <div className="text-xs font-semibold uppercase tracking-wider text-white/70">{n.tag}</div>
                <div className="mt-2 text-lg font-bold leading-tight">{n.title}</div>
              </div>
              <p className="mt-3 text-sm leading-relaxed text-foreground/80">{n.body}</p>
            </motion.article>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

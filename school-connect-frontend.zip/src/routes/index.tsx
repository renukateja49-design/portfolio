import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { Calendar, Cloud, Users, Wallet, ChevronRight, Sparkles } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { student } from "@/lib/mock-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Home – School Connect" },
      { name: "description", content: "Your daily school dashboard – attendance, fees, events and more." },
    ],
  }),
  component: HomePage,
});

const essentials = [
  { to: "/attendance", label: "Attendance", value: `${student.attendance}%`, sub: "As on today, 09:22 AM", tint: "mint", icon: Calendar },
  { to: "/fees", label: "Fee Payments", value: `INR ${student.fees.due.toLocaleString()}`, sub: "Dues as of today", tint: "rose", icon: Wallet },
  { to: "/showcase", label: "Campus Events", value: "5 upcoming", sub: "This week", tint: "violet", icon: Sparkles },
  { to: "/academics", label: "Campus Clubs", value: "12 active", sub: "Join your tribe", tint: "sky", icon: Users },
] as const;

function HomePage() {
  const hour = new Date().getHours();
  const greet = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
  const today = new Date().toLocaleDateString("en-IN", { weekday: "long", day: "2-digit", month: "long" });

  return (
    <AppShell
      centerTitle
      title={
        <div className="flex items-center justify-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-brand text-brand-foreground">
            <Sparkles className="h-4 w-4" />
          </div>
          <span className="text-sm font-bold tracking-[0.18em] text-brand">SCHOOL CONNECT</span>
        </div>
      }
    >
      <div className="px-4 pt-3">
        {/* Greeting card */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl bg-card shadow-card ring-1 ring-border"
        >
          <div className="flex items-start justify-between gap-3 p-4">
            <div>
              <div className="text-[17px] font-bold leading-tight">Hi {student.name.split(" ")[0]},</div>
              <div className="mt-1 text-sm text-muted-foreground">
                {greet}, {today}
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center justify-end gap-1.5 text-lg font-semibold">
                <Cloud className="h-5 w-5 text-tint-sky-foreground" /> 29°C
              </div>
              <div className="text-xs text-muted-foreground">Partly Cloudy</div>
            </div>
          </div>
          <Link to="/academics" className="flex items-center justify-between border-t border-border/70 px-4 py-3 hover:bg-secondary/50">
            <span className="font-semibold">View Schedule</span>
            <ChevronRight className="h-4 w-4 text-brand" />
          </Link>
        </motion.div>

        {/* Action centre */}
        <h2 className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Action Centre</h2>
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.05 }}
          className="mt-3 rounded-2xl bg-foreground p-5 text-background shadow-card"
        >
          <div className="text-[15px] font-bold leading-snug uppercase">Mid-term Feedback · June 2026</div>
          <div className="mt-3 flex items-end justify-between">
            <div className="text-sm text-background/60">17 Jun, 2026 – 26 Jun, 2026</div>
            <button className="text-sm font-semibold text-tint-violet">View</button>
          </div>
        </motion.div>

        {/* Essentials */}
        <h2 className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Essentials</h2>
        <div className="mt-3 grid grid-cols-2 gap-3">
          {essentials.map((e, i) => (
            <motion.div
              key={e.label}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.05 * i }}
            >
              <Link to={e.to}>
                <motion.div
                  whileTap={{ scale: 0.97 }}
                  className={`flex h-[160px] flex-col justify-between rounded-2xl bg-tint-${e.tint} p-4 shadow-card`}
                >
                  <div className={`grid h-10 w-10 place-items-center rounded-xl bg-tint-${e.tint}-foreground text-white`}>
                    <e.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className={`text-[15px] font-bold text-tint-${e.tint}-foreground`}>{e.label}</div>
                    <div className="mt-1 text-[13px] font-semibold text-foreground/80">{e.value}</div>
                    <div className="mt-0.5 text-[11px] text-foreground/55">{e.sub}</div>
                  </div>
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

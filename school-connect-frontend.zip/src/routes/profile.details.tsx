import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { student } from "@/lib/mock-data";

export const Route = createFileRoute("/profile/details")({
  head: () => ({ meta: [{ title: "Profile Details – School Connect" }] }),
  component: Details,
});

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <div className="text-[13px] text-muted-foreground">{label}</div>
      <div className="text-[15px] font-semibold">{value}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="bg-card px-5 py-6">
      <h2 className="border-b border-border pb-2 text-[20px] font-bold tracking-tight">{title}</h2>
      <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-5">{children}</div>
    </section>
  );
}

function Details() {
  return (
    <div className="mx-auto min-h-screen w-full max-w-[480px] bg-surface">
      <header className="sticky top-0 z-10 flex items-center gap-3 bg-card px-4 pb-4 pt-5">
        <Link to="/profile" className="-ml-1 rounded-lg p-2 hover:bg-secondary">
          <ArrowLeft className="h-5 w-5" />
        </Link>
        <h1 className="text-[22px] font-bold tracking-tight">Profile Details</h1>
      </header>

      <Section title="Personal Details">
        <Field label="Gender" value={student.gender} />
        <Field label="Date of birth" value={student.dob} />
        <div className="col-span-2"><Field label="Mobile" value={student.mobile} /></div>
        <div className="col-span-2"><Field label="E-Mail" value={student.email} /></div>
        <Field label="Father's Name" value={student.father} />
        <Field label="Mother's Name" value={student.mother} />
        <Field label="Parent's mobile" value={student.parentMobile} />
        <Field label="Blood group" value={student.bloodGroup} />
      </Section>

      <div className="h-2 bg-surface" />

      <Section title="Academic Details">
        <Field label="Roll number" value={student.roll} />
        <Field label="Batch" value={student.batch} />
        <Field label="Degree" value={student.degree} />
        <Field label="Program code" value={student.programCode} />
        <Field label="Semester Number" value={student.semester} />
        <Field label="Section" value={student.section} />
      </Section>
    </div>
  );
}

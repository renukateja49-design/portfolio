import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { AppShell } from "@/components/app-shell";
import { student } from "@/lib/mock-data";

export const Route = createFileRoute("/attendance")({
  head: () => ({ meta: [{ title: "Attendance – School Connect" }] }),
  component: Attendance,
});

function Ring({ value }: { value: number }) {
  const r = 78;
  const c = 2 * Math.PI * r;
  const color = value >= 90 ? "var(--tint-mint-foreground)" : value >= 75 ? "var(--tint-peach-foreground)" : "var(--destructive)";
  return (
    <svg viewBox="0 0 200 200" className="h-52 w-52">
      <circle cx="100" cy="100" r={r} stroke="var(--color-border)" strokeWidth="14" fill="none" />
      <motion.circle
        cx="100" cy="100" r={r} stroke={color} strokeWidth="14" fill="none" strokeLinecap="round"
        strokeDasharray={c}
        initial={{ strokeDashoffset: c }}
        animate={{ strokeDashoffset: c - (value / 100) * c }}
        transition={{ duration: 1.1, ease: "easeOut" }}
        transform="rotate(-90 100 100)"
      />
      <text x="100" y="98" textAnchor="middle" className="fill-foreground" fontSize="34" fontWeight="800">{value}%</text>
      <text x="100" y="122" textAnchor="middle" className="fill-muted-foreground" fontSize="12">Overall</text>
    </svg>
  );
}

function Attendance() {
  const stats = [
    { label: "Present", value: 154, tint: "mint" },
    { label: "Absent", value: 15, tint: "rose" },
    { label: "Working", value: 169, tint: "violet" },
  ] as const;
  return (
    <AppShell title="Attendance">
      <div className="flex flex-col items-center px-4 pt-4">
        <Ring value={student.attendance} />
        <div className="mt-2 text-sm text-muted-foreground">Excellent — keep it up!</div>

        <div className="mt-6 grid w-full grid-cols-3 gap-3">
          {stats.map((s) => (
            <div key={s.label} className={`rounded-2xl bg-tint-${s.tint} p-4 text-center shadow-card`}>
              <div className={`text-2xl font-extrabold text-tint-${s.tint}-foreground`}>{s.value}</div>
              <div className="mt-1 text-xs font-semibold text-foreground/70">{s.label}</div>
            </div>
          ))}
        </div>

        <div className="mt-6 w-full rounded-2xl bg-card p-4 shadow-card">
          <div className="mb-3 flex items-center justify-between">
            <div className="font-bold">This Month</div>
            <div className="text-xs text-muted-foreground">June 2026</div>
          </div>
          <div className="grid grid-cols-7 gap-1.5 text-center text-[11px]">
            {Array.from({ length: 30 }).map((_, i) => {
              const status = i % 9 === 0 ? "absent" : i % 7 === 6 ? "off" : "present";
              const cls =
                status === "present"
                  ? "bg-tint-mint text-tint-mint-foreground"
                  : status === "absent"
                  ? "bg-tint-rose text-tint-rose-foreground"
                  : "bg-secondary text-muted-foreground";
              return (
                <div key={i} className={`grid h-9 place-items-center rounded-lg font-semibold ${cls}`}>{i + 1}</div>
              );
            })}
          </div>
        </div>
      </div>
    </AppShell>
  );
}

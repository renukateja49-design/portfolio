import { createFileRoute } from "@tanstack/react-router";
import { Download } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { student } from "@/lib/mock-data";

export const Route = createFileRoute("/fees")({
  head: () => ({ meta: [{ title: "Fees – School Connect" }] }),
  component: Fees,
});

const history = [
  { date: "May 12, 2026", amount: 42500, ref: "INV-20451" },
  { date: "Dec 04, 2025", amount: 42500, ref: "INV-20312" },
];

function Fees() {
  const { total, paid, due } = student.fees;
  const pct = Math.round((paid / total) * 100);
  return (
    <AppShell title="Fee Payments">
      <div className="px-4 pt-2">
        <div className="rounded-2xl bg-gradient-brand p-5 text-brand-foreground shadow-card">
          <div className="text-xs uppercase tracking-wider text-white/70">Total annual fee</div>
          <div className="mt-1 text-3xl font-extrabold">INR {total.toLocaleString()}</div>
          <div className="mt-4 h-2 w-full overflow-hidden rounded-full bg-white/15">
            <div className="h-full rounded-full bg-tint-mint-foreground" style={{ width: `${pct}%` }} />
          </div>
          <div className="mt-3 flex justify-between text-sm">
            <span>Paid: INR {paid.toLocaleString()}</span>
            <span>Due: INR {due.toLocaleString()}</span>
          </div>
        </div>

        <h2 className="mt-6 text-xs font-bold uppercase tracking-[0.16em] text-muted-foreground">Payment History</h2>
        <div className="mt-3 space-y-2">
          {history.map((h) => (
            <div key={h.ref} className="flex items-center justify-between rounded-2xl bg-card p-4 shadow-card">
              <div>
                <div className="font-semibold">INR {h.amount.toLocaleString()}</div>
                <div className="text-xs text-muted-foreground">{h.date} · {h.ref}</div>
              </div>
              <button className="flex items-center gap-1.5 rounded-full bg-secondary px-3 py-1.5 text-xs font-semibold">
                <Download className="h-3.5 w-3.5" /> Receipt
              </button>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState } from "react";
import { AppShell } from "@/components/app-shell";
import { courses } from "@/lib/mock-data";

export const Route = createFileRoute("/academics")({
  head: () => ({ meta: [{ title: "Learning Management – School Connect" }] }),
  component: Academics,
});

function Academics() {
  const [tab, setTab] = useState<"courses" | "growth">("courses");
  return (
    <AppShell title="Learning Management">
      <div className="px-4 pt-1">
        <div className="grid grid-cols-2 border-b border-border">
          {(["courses", "growth"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="relative py-3 text-[15px] font-semibold capitalize"
            >
              <span className={tab === t ? "text-foreground" : "text-muted-foreground"}>{t}</span>
              {tab === t && (
                <motion.div layoutId="lm-underline" className="absolute inset-x-0 -bottom-px h-[3px] bg-destructive" />
              )}
            </button>
          ))}
        </div>

        {tab === "courses" ? (
          <>
            <div className="mt-5 text-sm font-medium text-muted-foreground">II Semester</div>
            <div className="mt-3 space-y-3">
              {courses.map((c, i) => (
                <motion.div
                  key={c.code}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  whileTap={{ scale: 0.985 }}
                  className="flex items-center gap-4 rounded-2xl bg-card p-3 shadow-card"
                >
                  <div className={`grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-tint-${c.tint}`}>
                    <span className={`text-base font-bold text-tint-${c.tint}-foreground`}>{c.code}</span>
                  </div>
                  <div className="min-w-0">
                    <div className="text-[15px] font-bold leading-tight">{c.name}</div>
                    <div className="mt-1 text-[13px] text-muted-foreground">{c.faculty}</div>
                  </div>
                </motion.div>
              ))}
            </div>
          </>
        ) : (
          <div className="mt-12 text-center text-muted-foreground">Growth charts coming soon.</div>
        )}
      </div>
    </AppShell>
  );
}

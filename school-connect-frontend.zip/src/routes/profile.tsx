import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ChevronRight, Calendar, GraduationCap, Wallet, Receipt } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { student } from "@/lib/mock-data";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Account – School Connect" }] }),
  component: Profile,
});

const tiles = [
  { to: "/attendance", icon: Calendar, label: "Attendance", sub: `Overall: ${student.attendance}%`, tint: "violet" },
  { to: "/results", icon: GraduationCap, label: "Exams", sub: `CGPA: ${student.cgpa}`, tint: "peach" },
  { to: "/fees", icon: Wallet, label: "Fee Payments", sub: `Due: INR ${student.fees.due}`, tint: "mint" },
  { to: "/fees", icon: Receipt, label: "Transactions", sub: "View history", tint: "rose" },
] as const;

function Profile() {
  return (
    <AppShell title="Account">
      <div className="px-4 pt-2">
        <Link to="/profile/details">
          <motion.div
            whileTap={{ scale: 0.985 }}
            className="flex items-center gap-4 rounded-2xl bg-gradient-brand p-3 text-brand-foreground shadow-card"
          >
            <div className="h-20 w-20 overflow-hidden rounded-xl bg-white/15 ring-1 ring-white/20">
              <img src={student.photo} alt={student.name} className="h-full w-full object-cover" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-[17px] font-bold uppercase tracking-wide">{student.name}</div>
              <div className="text-xs text-white/65">ID: {student.id}</div>
            </div>
            <ChevronRight className="h-5 w-5 opacity-80" />
          </motion.div>
        </Link>

        <div className="mt-4 grid grid-cols-2 gap-3">
          {tiles.map((t, i) => (
            <motion.div
              key={t.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.04 }}
            >
              <Link to={t.to}>
                <motion.div
                  whileTap={{ scale: 0.97 }}
                  className="relative flex h-[120px] flex-col justify-between rounded-2xl bg-card p-3 shadow-card"
                >
                  <div className={`grid h-9 w-9 place-items-center rounded-xl bg-tint-${t.tint} text-tint-${t.tint}-foreground`}>
                    <t.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <div className="text-[15px] font-bold leading-tight">{t.label}</div>
                    <div className="text-[12px] text-muted-foreground">{t.sub}</div>
                  </div>
                  <ChevronRight className="absolute right-3 top-3 h-4 w-4 text-brand" />
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}

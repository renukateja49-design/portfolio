import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/exams")({
  head: () => ({ meta: [{ title: "Exams – School Connect" }] }),
  component: Exams,
});

const schedule = [
  { date: "Jun 17", subject: "Mathematics", time: "9:30 – 12:30", hall: "Block A · 204" },
  { date: "Jun 19", subject: "Physics", time: "9:30 – 12:30", hall: "Block A · 204" },
  { date: "Jun 21", subject: "Chemistry", time: "9:30 – 12:30", hall: "Block A · 204" },
  { date: "Jun 23", subject: "English", time: "9:30 – 12:30", hall: "Block A · 204" },
  { date: "Jun 25", subject: "Computer Science", time: "9:30 – 12:30", hall: "Block A · 204" },
];

function Exams() {
  return (
    <AppShell title="Exams">
      <div className="px-4 pt-2">
        <button className="w-full rounded-2xl bg-gradient-brand p-4 text-left text-brand-foreground shadow-card">
          <div className="text-xs uppercase tracking-wider text-white/70">Half-Yearly Examinations</div>
          <div className="text-lg font-bold">Download Hall Ticket</div>
        </button>
        <div className="relative mt-6 pl-5">
          <div className="absolute bottom-2 left-2 top-2 w-px bg-border" />
          {schedule.map((s) => (
            <div key={s.subject} className="relative mb-4">
              <span className="absolute -left-3 top-1.5 h-3 w-3 rounded-full bg-brand ring-4 ring-surface" />
              <div className="rounded-2xl bg-card p-4 shadow-card">
                <div className="text-xs font-bold uppercase tracking-wider text-brand">{s.date}</div>
                <div className="mt-1 text-[15px] font-bold">{s.subject}</div>
                <div className="text-xs text-muted-foreground">{s.time} · {s.hall}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
